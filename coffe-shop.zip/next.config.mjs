/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["halochin.ir" , 'upload.wikimedia.org'], 
  },
};

export default nextConfig;

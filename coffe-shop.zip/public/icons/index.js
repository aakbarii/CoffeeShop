import homeIcon from "./home.svg";
import shopIcon from "./shop.svg";
import coffeeIcon from "./coffee.svg";
import infoIcon from "./info.svg";
import phoneIcon from "./phone.svg";
import articleIcon from "./article.svg";
import userIcon from "./user.svg";
import cartIcon from "./cart.svg";
import searchIcon from "./search.svg";
import menuIcon from "./bars.svg";
import waiteCoffeeIcon from "./waiteCoffeeIcon.svg";
import checkboxIcon from "./cheakBox.svg";
import questionIcon from "./question.svg";
import calendarIcon from "./calendar.svg";
import honarIcon from "./honar.svg";
import montakhabIcon from "./montakhab.svg";
import boxIcon from "./box.svg";
import ketabIcon from "./ketab.svg";
import sabkIcon from "./sabk.svg";
import gameIcon from "./game.svg";
import elmIcon from "./elm.svg";

export {
  homeIcon,
  shopIcon,
  coffeeIcon,
  infoIcon,
  phoneIcon,
  articleIcon,
  userIcon,
  cartIcon,
  searchIcon,
  menuIcon,
  waiteCoffeeIcon,
  checkboxIcon,
  questionIcon,
  calendarIcon,
  honarIcon,
  montakhabIcon,
  boxIcon,
  ketabIcon,
  sabkIcon,
  gameIcon,
  elmIcon,
};
